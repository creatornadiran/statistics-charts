from setuptools import setup

setup(name='scharts',
      version='0.1',
      description='Visualize statistical charts in easy way.',
      packages=['scharts'],
      author = 'Nadirhan Sahin',
      author_email = 'sahinadirhan@gmail.com',
      zip_safe=False)
